/*select all the necessary Elements*/

var input = document.querySelector('.todo_input');

var MainTodoContainer = document.getElementById('todos');

var addingButton = document.querySelector('.add-item');

var deleteAllBtn = document.querySelector('.deleteBtn');


addingButton.addEventListener('click',function(e){
   
   /*create all the elements*/
   
    if(input.value.trim()){
    	 
        /* UL Tag */
        var ulTag = document.createElement('ul');
        ulTag.classList.add('todo-list-container');
        /* Todo list div */
        var todoList = document.createElement('div');
        todoList.classList.add('todo-list');
        /* LI Tag */
        var liTag = document.createElement('li');
        liTag.innerText = input.value;
        liTag.classList.add('todo-item');
        /* Button Div */
        var buttonDiv = document.createElement('div');
        buttonDiv.classList.add('button');
        /* completed button element1 */
        var completeButton = document.createElement('button');
        completeButton.classList.add('completed');
        completeButton.innerHTML = '<i class="fa fa-check"></i>';
        /* Edit Button */
        var editBtn = document.createElement('button');
        editBtn.innerHTML = '<i class="fa fa-edit"></i>';
        editBtn.classList.add('editBtn');
        editBtn.onclick = function(){
            editWorking(liTag);
        }
        /* trash button element2 */
        var trashButton = document.createElement('button');
        trashButton.classList.add('trash');
        trashButton.innerHTML = '<i class="fa fa-trash"></i>';
    
        /* Appending Elements into each other */
        ulTag.appendChild(todoList);
        todoList.appendChild(liTag);
        todoList.appendChild(buttonDiv);
        buttonDiv.appendChild(completeButton);
        buttonDiv.appendChild(editBtn);
        buttonDiv.appendChild(trashButton);

        /*append all the element in main div*/

        MainTodoContainer.appendChild(ulTag);


        /*Complete and trash button working*/
         todoList.addEventListener('click',function(e){
             
             var items = e.target;
             if(items.classList[0] ==='completed'){
                   var todo = items.parentElement;
                   var todo2 = items.parentElement;
                   todo2.classList.add('line_through');

             }
            else if(items.classList[0] ==='trash'){
                   var todo = items.parentElement;
                   var todo2 = items.parentElement;
                   var todo3 = todo2.parentElement;
                   todo3.classList.add('fall');
                   todo3.addEventListener('transitionend',function(){})
                     todo3.remove();
             }


         });
        
        /*When the add button click clear the input value*/
        input.value='';
         


          

    }
    else if(input.value==''){
      alert('please fill the input filed');

    }



    
})

function editWorking(e){
   var editValue = prompt('edit the selected item', e.firstChild.nodeValue);
  e.firstChild.nodeValue = editValue;

    }


    function deleteAllElements(){
          var fettingUlTag = document.querySelectorAll('.todo-list-container');
          for(var i=0;i<gettinhUlTag.length;i++){
            gettingUlTag[i].remove();
          }
          input.value=='';
    }






